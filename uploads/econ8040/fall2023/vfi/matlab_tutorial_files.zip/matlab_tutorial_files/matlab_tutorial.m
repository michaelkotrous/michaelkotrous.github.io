% matlab_tutorial.m
% Author: Michael Kotrous
% Affilation: University of Georgia
% Class: ECON 8040
% Date: Aug. 26, 2022

% You can run this entire file by running the command: run('matlab_tutorial.m')
% To work through this file section-by-section, you can copy-and-paste chunks of
% code into the command window and hit return to execute that chunk

%% Workspace Configuration
% Clean up your workspace
clear; % clear workspace
clc; % clear command window

% Define working directory
% Option 1: Uncomment and edit the file path below
%cd 'path/to/matlab_tutorial_files';

% Option 2: Navigate through your filesystem
% using the left-hand "Current Folder" window
% in the Matlab console

%% Scalar math
% Define scalar variables
beta = 0.95;
r = 0.04;
sigma = 3;
w = 10;

% Pre-defined scalar variables
eps % arbitrarily small positive number
pi % 3.1416
i % sqrt(-1)
realmax % largest real number
realmin % smallest positive real number

% Scalar operations
2+2 % 4 displays in the matlab console
2+2; % adding semicolon suppresses output in the Matlab console
beta-1 % subtraction
3*4 % multiplication
r/2 % division
w^2 % w ``squared''
r^3 % r ``cubed''
sqrt(2) % square root of 2
exp(3) % e^3
log(1) % natural log of 1


% Multiple operations on one line
exp(i*pi) + 1
c = (beta*(1+r)*w)^(1/sigma)
% Important to remember the order of operations:
% 1. Parentheses
% 2. Exponents
% 3. Multiplication/Division
% 4. Addition/Subtraction

%% Random number generation
rng(01062022); % defines ``seed'' to produce same random numbers each time you run your script
rand(2) % creates 2x2 matrix of random numbers drawn from uniform distribution between 0 and 1
rand(10,1) % creates 10x1 vector of random numbers drawn from uniform distribution between 0 and 1
randn(3) % returns 3x3 matrix of scalars drawn from Standard Normal distribution
randn(1,5) % returns 1x5 vector of scalars drawn from Standard Normal distribution

%% Matrix / vector math
% See https://www.mathworks.com/help/matlab/math/basic-matrix-operations.html

% Create matrices and vectors
D = [1 0; -1 3]; % 2 x 2 matrix
D

A = [1 2 -1; 0 -4 2]; % 2 x 3 matrix
B = [0 1 -2; 3 0 0; -2 1 0]; % 3 x 3 matrix

u = 1:10 % 1x10 vector of integers from 1 to 10 (i.e., 1,2,3,...,10)
v = linspace(0,1,5) % 1x5 vector of 5 numbers evenly spaced between 0 and 1

% Pre-defined matrices
eye(2) % 2x2 identity matrix
zeros(10,1) % 10x1 vector of zeros
ones(3,4) % 3x4 matrix of ones
ones(20,1)*10 % 20x1 vector of 10's

% Matrix operations
% Be mindful of dimensions to avoid conformability errors!
size(A) % tells you the dimensions of matrix A; good for checking conformability
det(D) % determinant of A; det(A) = 0 <=> inv(A) does not exist
inv(D) % invert square matrix D
transpose(A) % transpose matrix A
A' % equivalent way to transpose matrix A
eye(2)-D % add D and 2x2 identity
% Verify that D+A produces error
A*B % matrix multiplication
% Verify that D*B produces error

% multiple matrix operations in one line: regress X on Y
X = rand(48,3);
Y = randn(48,1);
bhat = inv(X'*X)*X'*Y

% Matrix operations - element-wise
% Often you will want to perform operations on a matrix/vector element-by-element
% Add a period (.) immediately before the operation being performed
% e.g., squaring each value in a vector
(ones(20,1)*10).^2 % squares each element of the vector
% Verify that (ones(20,1)*10)^2 produces error message

% e.g., creating interaction variable
% multiplying two columns of X to produce new column
% X(:,1) selects all rows of the first column of X
X(:,4) = X(:,1).*X(:,2);
% Verify that X(:,1)*X(:,2) gives error

%% Logical operators / Conditional Logic
% x greater than y -->  "x > y"
% x gt or equal to y --> "x >= y"
% x less than y ----->  "x < y"
% x lt or equal to y --> "x <= y"
% x is equal to y --->  "x == y"  Note: you need to use two equals signs
% x not equal to y -->  "x ~= y"

% e,g, compare two scalars
e = exp(1); % Euler's constant
if e > pi 
    disp('Eulers constant is greater than pi');
elseif e < pi
    disp('Eulers constant is less than pi');
else 
    disp('Eulers constant is equal to pi');
end

% e.g., check for nonpositivity
% Recall c = (beta*(1+r)*w)^(1/sigma)
if c <= 0
    c = eps; % small positive number
    util = -10e10 % large negative number
end


%% For loops
% Useful when you need to perform fixed number of operations
% e.g., display integers from 1 to 5
for i = 1:5
    disp(i)
end

% e.g., display elements of a matrix
% Notice how we nest for loops
% to select rows and columns
dimA = size(A);
nrow = dimA(1);
ncol = dimA(2);
for i = 1:nrow 
    for j = 1:ncol
        disp(A(i,j))
    end
end

% We can also use condition logic inside of for loops
% e.g., create matrix M where 1 indicates strictly positive value in A,
%       0 indicates nonpositive value
M = zeros(nrow,ncol); % create zeros matrix with same dimensions as A
for i = 1:nrow 
    for j = 1:ncol
        if A(i,j) > 0
            M(i,j) = 1;
        end % stays zero otherwise
    end
end

A 
M % verify that M was constructed correctly


%% While loops
% Useful for value function iteration
% or when you want code to stop
% when certain condition is satisfied

maxit = 50;
it = 0;
while it < maxit
    it = it + 1;
    disp(it)
end
% the code stops when it reaches 50


%% Functions
% Custom functions can be made two ways
% 1. add to the bottom of the current file
% Note 1: The function must be at the _very_ bottom of the file, or 
% you will get an error message
% Note 2: If you copy-and-paste this line into the command window,
% you will get an error message. Matlab will only recognize this function 
% if you execute the entire file: run('matlab_tutorial.m')
kgrid1 = griddle(0,10,20,3);



% 2. Write function as a separate file
% Note 1: File must be in same directory
% Note 2: File name must match function name _exactly_
kgrid2 = griddleFile(0,10,20,3);

% Notice output of functions are equivalent
kgrid1
kgrid2


%% Exercise 1 
% World Bank Development Data:
% - Economic Freedom and per capita GDP
% - per capita GDP and income inequality

% Read CSV as table object
efdata = readtable('data-econfreedom.csv', 'ReadVariableNames', true);

% Plot 1: Economic Freedom and GDP per capita
lngdppcap = log(efdata.gdppcap); % We use period to access columns of table
efi_fraser = efdata.efi_fraser;
fit = polyfit(lngdppcap, efi_fraser, 1); % fit straight line
pts = linspace(min(lngdppcap), max(lngdppcap), 50); % x-values for drawing "line of best fit"

scatter(lngdppcap, efi_fraser);
xlabel('log(GDP per capita, 2019 USD)');
ylabel('Economic Freedom (Fraser Institute)');
title('Economic Freedom and Per Capita GDP in 2019');
hold on; % hold tells Matlab to keep the current plot in place
plot(pts, polyval(fit,pts)); % adds line of best on top of scatter plot
saveas(gcf, 'gdp-freedom-scatter.png'); % file saved in current directory
close; % closes plot window before making next plot


% Plot 2: Kuznets curve (GDP per capita and Income Inequality)
% We need to drop rows with NaN Gini values
idx = ~isnan(efdata.gini); % identify rows with Gini values; ~ means 'not'
gini = efdata.gini(idx); % gini is index measure of income inequality
lngdppcap = lngdppcap(idx); % subset for countries for which we observe Gini

fit2 = polyfit(lngdppcap, gini, 2); % fit quadratic to draw ``Kuznets Curve''

scatter(lngdppcap, gini);
xlabel('log(GDP per capita, 2019 USD)');
ylabel('Gini');
title('Per Capita GDP and Income Inequality in 2019');
hold on;
plot(pts, polyval(fit2,pts));
legend('', 'Kuznets Curve'); % first '' means no legend entry needed for dots
saveas(gcf, 'kuznetscurve.png'); % file saved in current directory
close; % closes plot window before making next plot


%% Exercise 2
% Multi-plot figure and time series

% Plot 3: Let's put two plots in one figure
tiledlayout(2,1); % this creates figure with two rows by one column

% Plot 3A: U.S. M2 Money Stock (Nov. 1980 -- Aug. 2022)
nexttile; % moves us to first "tile" (the top one)
m2 = readtable('m2.csv', 'ReadVariableNames', true);
plot(m2.date, m2.m2, 'LineWidth', 2);
xlabel('Time');
ylabel('Billions of Dollars');
title('M2 Money Stock, Nov. 1980 - Aug. 2022');

% Plot 3B: Detrend data and plot residuals/deviations from trend
nexttile; % moves to bottom "tile"
m2.m2_resid = detrend(m2.m2);
plot(m2.date, m2.m2_resid);
xlabel('Time');
yline(0, '--'); % draw dashed line at y = 0
title('Deviation from Trend -- M2 Money Stock, Nov. 1980 - Aug. 2022');
saveas(gcf, 'm2stock.png');
close;


%% Custom function for creating grids
% p = 1 is equivalent to linspace(a,b,n)
% p > 1 puts more points towards lower bound a
function g = griddle(a,b,n,p)
    gr = zeros(1,n);
    gr(1) = a;
    gr(n) = b;
    for k = 2:n-1 
        gr(k) = a + (b-a)*((k-1)/(n-1))^p;
    end
    g = gr;
    % We told Matlab g is the output of this function, so we assign its value at the end here
end
