% Solve Neoclassical growth model
% restrict search to grid points
% Author: Michael Kotrous
% Affilation: University of Georgia
% Class: ECON 8040
% Date: October 17, 2023

%% clean workspace
clear;
clc;

%% define parameters
a = 0.39;
b = 0.95;
d = 1;
z = 274;

% define tolerance/stopping criteria
tol = 1e-8;

%% discretize state space
n = 5;
kss = ((z*a)./(1/b - 1 + d))^(1/(1-a));
kgrid = zeros(1,n);
kgrid(:) = griddle(0.1*kss, 2*kss, n, 1.5);

ucgrid = zeros(n,n);
for i = 1:n 
    for j = 1:n
        c = z*kgrid(i)^a + (1-d)*kgrid(i) - kgrid(j);
        if c > 0
            ucgrid(i,j) = log(c);
        else 
            ucgrid(i,j) = -1e20;
        end
    end
end

disp(ucgrid);

%% define initial guess
V = linspace(0,1,n); % initial guess of value function
Tv = zeros(1,n); % Bellman operator
g = zeros(1,n); % policy function

%% update initial guess
Vgrid = zeros(n,n); % initialize matrix for showing how updating works
for i = 1:n
    Vgrid(i,:) = ucgrid(i,:) + b*V;
    [vmax, kmax] = max(ucgrid(i,:) + b*V);
    Tv(i) = vmax;
    g(i) = kgrid(kmax);
end

disp(Vgrid);
disp(Tv);
disp(g);

err1 = norm(V-Tv); % Eucliean norm
err2 = abs(max(V-Tv)); % maximum difference between adjacent values

%% enter value function iteration
V = Tv;
err = err1;
it = 0;
while err > tol && it < 500
    tic;
    for i = 1:n
        [vmax, kmax] = max(ucgrid(i,:) + b*V);
        Tv(i) = vmax;
        g(i) = kgrid(kmax);
    end
    
    % check for convergence and update guess
    err = norm(V - Tv);
    V = Tv;
    it = it+1;

    % display error every 50 iterations
    if mod(it,50) == 0
        disp(strcat('Iteration=', num2str(it)));
        disp(strcat('Error=', num2str(err)));
    end
end

if it < 500
    disp(strcat('Converged at it=', num2str(it)));
    disp(strcat('Error=', num2str(err)));
else
    disp('Failed to converge');
end
toc;

%% plot result
% Benchmark: we have analytical result for g(k) in full depreciation
gstar = (a*b*z)*kgrid.^a;
kstar = (a*b*z)^(1/(1-a));

newcolors = [0.00 0.00 0.00
             0.00 0.19 0.29
             0.84 0.16 0.16
             0.00 0.00 0.00];

colororder(newcolors);
plot(kgrid(1,:), kgrid(1,:), '--');
hold on;
plot(kgrid(1,:), gstar, '-', 'LineWidth', 1.5);
plot(kgrid(1,:), g(1,:), '-','LineWidth', 1.5);
plot(kstar,kstar,'*');
%title('Policy Function, Full Depreciation');
xlabel('k');
ylabel('g(k)');
legend('', 'Analytical', 'VFI', '', 'Location', 'Northwest');
xlim([0.1*kss(1),2*kss(1)]);
ylim([0.1*kss(1),2*kss(1)]);
grid on;